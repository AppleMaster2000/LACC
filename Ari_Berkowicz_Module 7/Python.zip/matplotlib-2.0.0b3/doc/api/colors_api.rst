******
colors
******

For a visual representation of the matplotlib colormaps, see the
"Color" section in the gallery.


:mod:`matplotlib.colors`
========================

.. automodule:: matplotlib.colors
   :members:
   :undoc-members:
   :show-inheritance:
