****
text
****


:mod:`matplotlib.text`
=======================

.. automodule:: matplotlib.text
   :members:
   :undoc-members:
   :show-inheritance:
