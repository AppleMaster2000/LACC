
:mod:`matplotlib.backends.backend_svg`
======================================

.. automodule:: matplotlib.backends.backend_svg
   :members:
   :show-inheritance:
