****************
dviread
****************

:mod:`matplotlib.dviread`
=========================

.. automodule:: matplotlib.dviread
   :members:
   :undoc-members:
   :show-inheritance:
