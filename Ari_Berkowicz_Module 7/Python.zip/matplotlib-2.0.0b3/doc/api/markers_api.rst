*******
Markers
*******


:mod:`matplotlib.markers`
=========================

.. automodule:: matplotlib.markers
   :members:
   :undoc-members:
   :show-inheritance:
