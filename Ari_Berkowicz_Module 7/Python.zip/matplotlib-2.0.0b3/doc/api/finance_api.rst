*******
finance
*******


:mod:`matplotlib.finance`
=========================

.. automodule:: matplotlib.finance
   :members:
   :undoc-members:
   :show-inheritance:
