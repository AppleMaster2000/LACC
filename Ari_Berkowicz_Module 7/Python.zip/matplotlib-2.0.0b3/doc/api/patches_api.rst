*******
patches
*******


:mod:`matplotlib.patches`
=========================

.. automodule:: matplotlib.patches
   :members:
   :undoc-members:
   :show-inheritance:
