****
axes
****


:mod:`matplotlib.axes`
======================

.. autoclass:: matplotlib.axes.Axes
   :members:
   :undoc-members:
   :inherited-members:
