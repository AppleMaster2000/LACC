.. _using-git:

Working with *matplotlib* source code
======================================

Contents:

.. toctree::
   :maxdepth: 2

   git_intro
   git_install
   following_latest
   git_development
   git_resources
   patching
