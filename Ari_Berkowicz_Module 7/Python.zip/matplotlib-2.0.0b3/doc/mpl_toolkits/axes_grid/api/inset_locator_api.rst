:mod:`mpl_toolkits.axes_grid1.inset_locator`
============================================

.. automodule:: mpl_toolkits.axes_grid1.inset_locator
   :members:
   :undoc-members:
   :show-inheritance:
